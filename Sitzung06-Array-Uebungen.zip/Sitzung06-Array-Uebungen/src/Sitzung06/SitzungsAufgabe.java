package Sitzung06;

public class SitzungsAufgabe {

	public static void main(String[] args) {
		SitzungsAufgabe instanz = new SitzungsAufgabe();
		instanz.findSingleDuplicate();
		instanz.countDuplicates();
		instanz.bubblesort();
		instanz.bubblesortOptimized();
	}
	
	public void findSingleDuplicate() {
		/* Implementierung: Doppelte Zahl in unsortiertem Array finden
		 * Gegeben sein ein int-Array in dem Zahlen zwischen 0 und 9 vorkommen, z.B. {9,1,2,5,4,3,2,8,7}
		 * wobei eine Zahl doppelt vorkommt. Jede andere Zahl kommt nur 1mal vor.
		 * Finde die doppelte Zahl
		 * */
		
		System.out.println("Finde doppelte Zahl:");
		int[] numbers = {9,1,2,5,4,3,2,8,7};
		
		int[] occ = {0,0,0,0,0,0,0,0,0,0};
		
		for (int num : numbers) {
			occ[num]++;
			if (occ[num] > 1) {
				System.out.println(num);
				break;
			}
		}
	}
	
	public void countDuplicates() {
		/* Implementierung: Doppelte Zahlen in Arrays zählen
		 * Gegeben sein ein int-Array in dem Zahlen zwischen 0 und 9 vorkommen, z.B. {9,1,2,5,4,3,2,8,7,1,5,9,9}.
		 * Zahlen können mehrfach vorkommen.
		 * Zähle und gebe aus, wie oft die Zahlen vorkommen
		 * */
		
		System.out.println("Zähle doppelte Zahlen:");
		int[] numbers = {9,1,2,5,4,3,2,8,7,1,5,9,9};
		
		int[] occ = {0,0,0,0,0,0,0,0,0,0};
		
		for (int num : numbers) {
			occ[num]++;
		}
		
		for (int i = 0; i < occ.length; i++) {
			System.out.println("Die Zahl " + i + " kommt " + occ[i] + " mal vor!");
		}
	}
	
	public void bubblesort() {
		/* Implementierung: Bubblesort
		 * Gegeben sei ein int-Array in dem Zahlen vorkommen,
		 * z.B. {9,3,4,2,9,9,8,6,4,8,1,5,3,5,10,3,5,9,6,3}.
		 * Zahlen können mehrfach vorkommen.
		 * Sortiere die Zahlen aufsteigend,
		 * also die kleinste Zahl an erster Stelle
		 * und die höchste Zahl an letzter Stelle im ursprünglichen Array
		 * */
		System.out.println("Bubblesort:");
		int[] numbers = {9,3,4,2,9,9,8,6,4,8,1,5,3,5,10,3,5,9,6,3};
		
		for (int i = 0; i < numbers.length - 1; i++) {
			for (int j = 0; j < numbers.length - 1; j++) {
				if (numbers[j] > numbers[j + 1]) {
					int temp = numbers[j + 1];
					numbers[j + 1] = numbers[j];
					numbers[j] = temp;
				}
			}			
		}
		
		for (int num : numbers) {
			System.out.print(num + " ");
		}
		System.out.println();
	}
	
	public void bubblesortOptimized() {
		// Selbe Aufgabe wie davor, aber optimierter
		System.out.println("Optimizertes Bubblesort:");
		
		int[] numbers = {9,3,4,2,9,9,8,6,4,8,1,5,3,5,10,3,5,9,6,3};
		boolean swapped = false;
		
		for (int i = 0; i < numbers.length - 1; i++) {
			swapped = false;
			for (int j = 0; j < numbers.length - i - 1; j++) {
				if (numbers[j] > numbers[j + 1]) {
					int temp = numbers[j + 1];
					numbers[j + 1] = numbers[j];
					numbers[j] = temp;
					swapped = true;
				}
			}
			if (!swapped) {
				System.out.println("Sortiert nach " + (i + 1) + " Iterationen von " + numbers.length );
				break;
			}
		}
		
		for (int num : numbers) {
			System.out.print(num + " ");
		}	
	}

}
