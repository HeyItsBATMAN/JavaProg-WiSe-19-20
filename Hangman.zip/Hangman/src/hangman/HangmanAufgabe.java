package hangman;

// Wir benutzen Random um zufällig ein Wort auszusuchen
import java.util.Random;
// Wir benutzen Scanner um den Nutzerinput einzulesen
import java.util.Scanner;

public class HangmanAufgabe {

	public static void main(String[] args) {
		/* NAIVES HANGMAN:
		 * - Hallo -> Anleitung (OPTIONAL)
		 * - Zu erratendes Wort aus einer Sammlung an Worten (Array) mit Random
		 * - Zu erratendes Wort mit Strichen darstellen (#), je 1 Hashtag/Pound pro 1 Buchstabe (in Hilfsfunktion)
		 * - Fehlversuche werden gezählt (z.B. mit Integer)
		 * - Richtig erratene Buchstaben in String speichern
		 * - Schleife läuft bis 1. alle Buchstaben erraten wurden oder 2. alle Leben wegen sind/der Hangman hängt
		 * 	 - Darstellung des zu erratenden Wortes
		 *   - Nutzereingabe
		 *   - Länge der Eingabe überprüfen
		 *   	- Wenn zu lang (oder Zahl oder so), Meldung (continue) (OPTIONAL)
		 *   	- Sonst gucken ob die Eingabe im Wort ist (contains)
		 *   		- Ist drin, Meldung und Buchstaben aufdecken (mit Hilfsfunktion)
		 *   		- Ist nicht drin, Fehlversuch
		 *   
		 *   
		 *   Zur Hilfe:
		 *   - Es werden mehrere Variablen gebraucht um den aktuellen Spielzustand zu wissen
		 *   	z.B. mindestens Fehlversuche, ein aufgedecktes und ein verdecktes Wort, aber
		 *   	man darf auch gerne mehr Variablen benutzen, wenn man dies für nötig hält
		 *   - Unten sind schon Random, Scanner und 2 Hilfsfunktionen vorgegeben
		 *   - Man darf auch gerne mit einem festen Wort anfangen, statt ein zufälliges zu nehmen,
		 *   	um sich die Implementierung zu vereinfachen
		 *   - Die Hilfsfunktionen geben beide jeweils einen neuen String zurück,
		 *   	d.h. sie überschreiben *nicht* die Variablen, die man als Parameter
		 *   	an die Methoden gibt 
		 */
		
		/* Zur Erinnerung:
		 * Random kann mit der Methode randInt() zufällige Integer erzeugen.
		 * Mit randInt(10) wären diese limitiert auf Zahlen von 0-9 (also ohne 10) */ 
		Random rand = new Random();
		/* Zur Erinnerung:
		 * Mit dem Scanner kann man Nutzereingaben auslesen
		 * z.B. hat der Nutzer mit der Methode nextLine() die Möglichkeit, eine Zeile Text einzugeben */
		Scanner input = new Scanner(System.in);
		
		// Code hier
		
		input.close();		
	}
	
	/**
	 * Hilfsfunktion für Hangman zum Aufdecken von Buchstaben
	 * @param verdWort - Das Wort mit verdeckten Feldern, die aufgedeckt werden müssen
	 * @param suchWort - Das richtige Wort, welches der Spieler erraten muss
	 * @param buchstabe - Der Buchstabe, den der Spieler eingegeben hat
	 * @return Gibt das "verdWort" mit aufgedeckten Buchstaben zurück
	 */
	public static String reveal(String verdWort, String suchWort, char buchstabe) {
		for (int i = 0; i < suchWort.length(); i++) {
			if (suchWort.charAt(i) == buchstabe) {
				// Wandle unser verdecktes Wort in char[] um
				char[] temp = verdWort.toCharArray();
				// Setze verdecktes Wort an der Stelle mit dem gefunden Buchstaben
				// zu dem gefundenen Buchstaben
				temp[i] = buchstabe;
				// Wandle char[] wieder zu String um, und gebe diesen zurück
				verdWort = String.valueOf(temp);
			}
		}
		return verdWort;
	}
	
	/**
	 * Hilfsfunktion für Hangman zum verdecken eines Wortes
	 * @param suchWort - Das richtige Wort, welches der Spieler erraten muss
	 * @return Gibt einen String zurück mit der selben Länge wie das "suchWort",
	 * aber jeder Buchstabe ist ein '#'
	 */
	public static String hide(String suchWort) {
		// Fange mit einem leeren String an
		String verdWort = "";
		// Füge dem String für jedes Zeichen im Suchwort ein Verdeckt-Zeichen hinzu
		for (int i = 0; i < suchWort.length(); i++) {
			verdWort += "#";
		}
		// Gebe das verdeckte Wort zurück
		return verdWort;
	}
}
