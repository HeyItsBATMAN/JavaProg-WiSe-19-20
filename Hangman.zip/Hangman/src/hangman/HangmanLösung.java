package hangman;

// Wir benutzen Random um zufällig ein Wort auszusuchen
import java.util.Random;
// Wir benutzen Scanner um den Nutzerinput einzulesen
import java.util.Scanner;

public class HangmanLösung {

	public static void main(String[] args) {
		/* Viel Platz, damit man nicht "aus Versehen" die Lösung sieht
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 */
		
		
		/* NAIVES HANGMAN:
		 * - Hallo -> Anleitung (OPTIONAL)
		 * - Zu erratendes Wort aus einer Sammlung an Worten (Array) mit Random
		 * - Zu erratendes Wort mit Strichen darstellen (#), je 1 Hashtag/Pound pro 1 Buchstabe (in Hilfsfunktion)
		 * - Fehlversuche werden gezählt (z.B. mit Integer)
		 * - Richtig erratene Buchstaben in String speichern
		 * - Schleife läuft bis 1. alle Buchstaben erraten wurden oder 2. alle Leben wegen sind/der Hangman hängt
		 * 	 - Darstellung des zu erratenden Wortes
		 *   - Nutzereingabe
		 *   - Länge der Eingabe überprüfen
		 *   	- Wenn zu lang (oder Zahl oder so), Meldung (continue) (OPTIONAL)
		 *   	- Sonst gucken ob die Eingabe im Wort ist (contains)
		 *   		- Ist drin, Meldung und Buchstaben aufdecken (mit Hilfsfunktion)
		 *   		- Ist nicht drin, Fehlversuch
		 */

		// Wortliste kann beliebig lang sein ...
		String[] wörter = {"Kimon", "Max", "Corinna"};
		Random rand = new Random();
		
		// ... da hier die Länge der Wortliste als Limit der Zufallsgeneration gesetzt wird
		String suchWort = wörter[rand.nextInt(wörter.length)].toUpperCase();
		// Nutze die Hilfsfunktion um das Wort zu verdecken
		String verdWort = hide(suchWort);
		// Erratene Buchstaben merken
		String erraten = "";
		
		// Fehlversuche und Spielstatus
		int versuche = 5;
		boolean lebendig = true;
		boolean gewonnen = false;
		
		Scanner input = new Scanner(System.in);
		
		// Der Loop beschreibt die Spiellogik
		while(lebendig && !gewonnen) {
			System.out.println("Verbleibende Versuche: " + versuche);
			if (erraten.length() > 0) {
				System.out.println("Bereits erraten: " + erraten);
			}
			System.out.println(verdWort);
			System.out.print("Eingabe: ");

			// Leichtes Errorhandling
			// Überprüft aktuell nur, ob überhaupt eine Eingabe stattgefunden hat
			char buchstabe;
			try {
				buchstabe = input.nextLine().toUpperCase().toCharArray()[0];
			} catch (Exception e) {
				System.out.println("Keine gültige Eingabe");
				// Springe zum Anfang des Loops, zähle aber keinen Fehlversuch
				continue;
			}

			// Überprüfe ob der Buchstabe im Wort vorkommt
			if (suchWort.contains(String.valueOf(buchstabe))) {
				System.out.println("Treffer");
				
				erraten += buchstabe;
				
				// Decke mit der Hilfsfunktion auf und überschreibe verdecktes Wort
				verdWort = reveal(verdWort, suchWort, buchstabe);
				
				// Wenn keine verdeckten Buchstaben mehr vorhanden sind,
				// setze den Spielstatus auf gewonnen
				if (!verdWort.contains("#")) {
					gewonnen = true;
				}
			} else {
				System.out.println("Fehler");
				
				// Reduziere die Anzahl an Versuchen und beende das Spiel,
				// wenn keine Versuche mehr übrig sind
				versuche--;
				if (versuche <= 0) {
					lebendig = false;
				}
			}
			
			// Trennstrich
			System.out.println("======================");
		}

		// Zeige Endresultat
		if (gewonnen) {
			System.out.println("Gewonnen! Das Wort war: " + suchWort);
		} else if (!lebendig) {
			System.out.println("Verloren :( Das Wort war: " + suchWort);
		} else {
			System.out.println("Wie bist du hier gelandet?");
		}
		
		input.close();
	}
	
	/**
	 * Hilfsfunktion für Hangman zum Aufdecken von Buchstaben
	 * @param verdWort - Das Wort mit verdeckten Feldern, die aufgedeckt werden müssen
	 * @param suchWort - Das richtige Wort, welches der Spieler erraten muss
	 * @param buchstabe - Der Buchstabe, den der Spieler eingegeben hat
	 * @return Gibt das "verdWort" mit aufgedeckten Buchstaben zurück
	 */
	public static String reveal(String verdWort, String suchWort, char buchstabe) {
		for (int i = 0; i < suchWort.length(); i++) {
			if (suchWort.charAt(i) == buchstabe) {
				// Wandle unser verdecktes Wort in char[] um
				char[] temp = verdWort.toCharArray();
				// Setze verdecktes Wort an der Stelle mit dem gefunden Buchstaben
				// zu dem gefundenen Buchstaben
				temp[i] = buchstabe;
				// Wandle char[] wieder zu String um, und gebe diesen zurück
				verdWort = String.valueOf(temp);
			}
		}
		return verdWort;
	}
	
	/**
	 * Hilfsfunktion für Hangman zum verdecken eines Wortes
	 * @param suchWort - Das richtige Wort, welches der Spieler erraten muss
	 * @return Gibt einen String zurück mit der selben Länge wie das "suchWort",
	 * aber jeder Buchstabe ist ein '#'
	 */
	public static String hide(String suchWort) {
		// Fange mit einem leeren String an
		String verdWort = "";
		// Füge dem String für jedes Zeichen im Suchwort ein Verdeckt-Zeichen hinzu
		for (int i = 0; i < suchWort.length(); i++) {
			verdWort += "#";
		}
		// Gebe das verdeckte Wort zurück
		return verdWort;
	}
}
