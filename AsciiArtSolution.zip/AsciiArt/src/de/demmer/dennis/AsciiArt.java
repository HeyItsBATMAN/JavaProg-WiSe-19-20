package de.demmer.dennis;

public class AsciiArt {

	public static void main(String[] args) {
		AsciiArt art = new AsciiArt();
		art.printAsciiArt("test2.png", 400);
	}	

	public void printAsciiArt(String imageFilePath, int widthInChars){
		
		float [][] intensity = PixelIntensity.getPixelIntensity(imageFilePath, widthInChars);
		char[] chars = {' ', '.','-','+','#'};
		boolean skip = true;
		
		for (float[] line : intensity) {
			skip = !skip;
			if (skip) continue;
			for (float point : line) {
				System.out.print(chars[(int)((point * 100) / 25)]);
			}
			System.out.println();
		}		
		
	}
	

}