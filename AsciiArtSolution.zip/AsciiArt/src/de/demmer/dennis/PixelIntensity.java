package de.demmer.dennis;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class PixelIntensity {
	
	
	/**
	 * Returns a matrix of values between 0 and 1 representing
	 * the color intensity (or darkness) of each pixel of the
	 * given image. The image will be scaled to the given pixel width
	 * beforehand.
	 * @param imageFilePath
	 * @param pixelWidth
	 * @return
	 */
	public static float[][] getPixelIntensity(String imageFilePath, int pixelWidth) {
		File imageFile = new File(imageFilePath);
		if (!(imageFile.exists() && imageFile.isFile() && imageFile.canRead())) {
			System.err.println("Error: '" + imageFile.getAbsolutePath() + 
					"' is not an existing, readable file!");
			return null;
		}
		//get BufferedImage instance
		BufferedImage image = getBufferedImage(imageFile);
		//scale image to 80 pixels width
		image = toBufferedImage(image.getScaledInstance(pixelWidth, -1, java.awt.Image.SCALE_FAST));
		//prep image props
		int width = image.getWidth();
		int height = image.getHeight();
		
		//generate pixel data
		float[][] data = new float[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				float k = (image.getRGB(x, y) & 0xff) +
						((image.getRGB(x, y) & 0xff00) >> 8) +
						((image.getRGB(x, y) & 0xff0000) >> 16);
				data[y][x] = 1f - (k / 3f / 255f);
			}
		}
		
		//dispose graphics data
		image.getGraphics().dispose();
		
		return data;
	}
	
	
	private static BufferedImage getBufferedImage(File imageFile) {
		try {
			return ImageIO.read(imageFile);
		} catch (IOException e) {
			System.err.println("Error reading file as image: " + imageFile.getAbsolutePath());
		}
		return null;
	}


	private static BufferedImage toBufferedImage(Image img) {
		// Create a buffered image with transparency
		BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		// Draw the image on to the buffered image
		Graphics2D bGr = bimage.createGraphics();
		bGr.drawImage(img, 0, 0, null);
		bGr.dispose();
		// Return the buffered image
		return bimage;
	}

}
